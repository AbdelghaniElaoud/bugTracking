package com.example.bugreporting.model;

public enum UserRole {
    ADMIN,TECH,CLIENT
}
