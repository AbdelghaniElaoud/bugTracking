package com.example.bugreporting.service;

import com.example.bugreporting.repository.UserRepository;

public class UserService {
}
