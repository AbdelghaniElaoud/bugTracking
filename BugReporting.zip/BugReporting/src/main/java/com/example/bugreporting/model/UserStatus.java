package com.example.bugreporting.model;

public enum UserStatus {
    ACTIVE, BLOCKED
}
