package com.example.bugreporting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BugReportingApplicationTests {

    @Test
    void contextLoads() {
    }

}
